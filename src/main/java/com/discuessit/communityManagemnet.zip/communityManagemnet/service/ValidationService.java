package com.discuessit.communityManagemnet.service;

import com.discuessit.communityManagemnet.model.Community;
import com.discuessit.communityManagemnet.model.CommunityMember;
import com.discuessit.communityManagemnet.model.MembershipStatus;
import com.discuessit.communityManagemnet.repository.CommunityMemberRepository;
import com.discuessit.communityManagemnet.repository.CommunityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ValidationService {



}
