package com.discuessit.communityManagemnet.service;

import io.helidon.webclient.api.WebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

@Service
public class UserVerifierService {


//    private WebClient webClient;
//
//    @Autowired
//    public UserVerifierService(WebClient.Builder webClientBuilder) {
//        this.webClient = webClientBuilder
//                .baseUrl("http://localhost:8080/user-management-service")
//                .build();
//    }
//
//    public void verifyUserExistsAndLoggedIn(Long userId, String token) {
//        try {
//            Boolean result = webClient.get()
//                    .uri(uriBuilder -> uriBuilder
//                            .path("/users/{id}/verify")
//                            .build(userId))
//                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
//                    .retrieve()
//                    .bodyToMono(Boolean.class)
//                    .block();
//
//            if (result == null || !result) {
//                throw new IllegalStateException("User not found or not logged in");
//            }
//
//        } catch (WebClientResponseException e) {
//            throw new IllegalStateException("Failed to verify user: " + e.getMessage(), e);
//        }
//    }
}
