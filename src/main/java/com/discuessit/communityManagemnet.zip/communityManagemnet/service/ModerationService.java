package com.discuessit.communityManagemnet.service;

import com.discuessit.communityManagemnet.mapper.CommunityMapper;
import com.discuessit.communityManagemnet.mapper.ModeratorMapper;
import com.discuessit.communityManagemnet.dto.controllerDTO.ModeratorPrivilegesResponse;
import com.discuessit.communityManagemnet.dto.serviceDTO.AssignNewModeratorCommand;
import com.discuessit.communityManagemnet.dto.serviceDTO.ModeratorDto;
import com.discuessit.communityManagemnet.model.*;
import com.discuessit.communityManagemnet.repository.*;
import jakarta.validation.Valid;
import org.hibernate.validator.internal.util.stereotypes.Lazy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ModerationService {

    @Autowired
    private ModeratorRepository moderatorRepository;
    @Autowired
    private PrivilegeRepository privilegeRepository;
    @Autowired
    private ModeratorPrivilegeRepository moderatorPrivilegeRepository;
    @Autowired
    private ModeratorMapper moderatorMapper;
    @Autowired
    private CommunityRepository communityRepository;
    @Autowired
    private CommunityMapper communityMapper;
    @Autowired
    @Lazy
    private CommunityService communityService;
    @Autowired
    private CommunityMemberRepository communityMemberRepository;


    @Transactional
    public Moderator assignCommunityMemberAsModeratorWithAllPrivileges(CommunityMember communityMember){

        Moderator moderator = Moderator.builder()
                .member(communityMember)
                .assignedBy(null)
                .deleted(false)
                .build();

       moderator= moderatorRepository.save(moderator);
        assignAllPrivileges(moderator);
        return moderator;
    }

    private void assignAllPrivileges(Moderator moderator){

        List<Privilege> allPrivileges = privilegeRepository.findAll();

        List<ModeratorPrivilege> moderatorPrivileges = allPrivileges.stream()
                .map(privilege -> ModeratorPrivilege.builder()
                        .moderator(moderator)
                        .privilege(privilege)
                        .build()
                )
                .toList();

        moderatorPrivilegeRepository.saveAll(moderatorPrivileges);
    }

    @Transactional
    public Moderator assignMemberAsModeratorWithSpecificPrivileges(
          @Valid AssignNewModeratorCommand assignModeratorCommand
    ) {
        Moderator assigner=verifyModeratorExists(assignModeratorCommand.getAssignedByModeratorId());
        Community  community=communityService.verifyCommunityExists(assignModeratorCommand.getCommunityId()) ;
        CommunityMember  member=communityService.verifyCommunityMemberExists(assignModeratorCommand.getMemberToBeModeratorId());

            Moderator moderator = Moderator.builder()
                    .member(member)
                    .assignedBy(assigner)
                    .deleted(false)
                    .build();

            Moderator createdModerator= moderatorRepository.save(moderator);
            assignPrivileges(createdModerator, assignModeratorCommand.getPrivilegesList());

            return createdModerator;
    }

    private void assignPrivileges(Moderator moderator, List<ModeratorPrivilegeType> privilegesList) {
        List<Privilege> privileges = getPrivilegesFromEnum(privilegesList);

        List<ModeratorPrivilege> moderatorPrivileges = privileges.stream()
                .map(privilege -> ModeratorPrivilege.builder()
                        .moderator(moderator)
                        .privilege(privilege)
                        .build())
                .toList();

        moderatorPrivilegeRepository.saveAll(moderatorPrivileges);
    }

    public List<Privilege> getPrivilegesFromEnum(List<ModeratorPrivilegeType> types) {
        return types.stream()
                .map(type -> privilegeRepository.findByType(type)
                        .orElseThrow(() -> new RuntimeException("Privilege not found: " + type.name())))
                .toList();
    }

    public ModeratorPrivilegesResponse getPrivilegesByModeratorId(Long moderatorId) {
        List<ModeratorPrivilege> moderatorPrivileges = moderatorPrivilegeRepository.findByModeratorId(moderatorId);
        if(moderatorPrivileges.isEmpty()){
            throw new IllegalArgumentException("moderator either not found or has no privileges !!");
        }else{
            List<ModeratorPrivilegeType> privilegeTypes = moderatorPrivileges.stream()
                    .map(mp -> ModeratorPrivilegeType.valueOf(mp.getPrivilege().getType().toString()))
                    .toList();

            return new ModeratorPrivilegesResponse(moderatorId, privilegeTypes);
        }
    }

    public void validateModeratorBelongsToCommunity(Long moderatorId, Long communityId) {
        Moderator moderator = moderatorRepository.findById(moderatorId)
                .orElseThrow(() -> new IllegalArgumentException("Moderator not found"));

        if (!moderator.getMember().getCommunity().getId().equals(communityId)) {
            throw new IllegalStateException("Moderator does not belong to the specified community");
        }
    }

    public void assertModeratorHasPrivilege(Long moderatorId, ModeratorPrivilegeType requiredPrivilege) {
        ModeratorPrivilegesResponse response = getPrivilegesByModeratorId(moderatorId);

        if (!response.privileges().contains(requiredPrivilege)) {
            throw new IllegalStateException("Moderator lacks required privilege: " + requiredPrivilege.name());
        }
    }

    public Moderator verifyModeratorExists(Long moderatorId) {
        return moderatorRepository.findById(moderatorId)
                .orElseThrow(() -> new IllegalArgumentException("Moderator not found with ID: " + moderatorId));
    }



}
