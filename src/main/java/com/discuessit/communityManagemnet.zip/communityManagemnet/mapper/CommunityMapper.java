package com.discuessit.communityManagemnet.mapper;

import com.discuessit.communityManagemnet.dto.controllerDTO.CommunityResponse;
import com.discuessit.communityManagemnet.dto.controllerDTO.CreateCommunityRequest;
import com.discuessit.communityManagemnet.dto.serviceDTO.CommunityDto;
import com.discuessit.communityManagemnet.dto.serviceDTO.CreateCommunityCommand;
import com.discuessit.communityManagemnet.model.Community;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CommunityMapper {

    // Controller request → service DTO
    CommunityDto toCommunityDto(CreateCommunityRequest request);

    // Controller request → command
    CreateCommunityCommand toCommunityCommand(CreateCommunityRequest createCommunityRequest);

    // Service DTO → controller response
    CommunityResponse toCommunityResponse(CommunityDto dto);

    // Entity → controller response
    CommunityResponse toCommunityResponse(Community community);

    // Entity → service DTO
    CommunityDto toCommunityDto(Community community);

    // Command → entity
    Community toCommunityEntity(CreateCommunityCommand createCommunityCommand);
}

