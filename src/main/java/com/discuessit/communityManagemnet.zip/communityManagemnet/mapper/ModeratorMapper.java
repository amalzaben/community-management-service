package com.discuessit.communityManagemnet.mapper;

import com.discuessit.communityManagemnet.dto.controllerDTO.AssignNewModeratorRequest;
import com.discuessit.communityManagemnet.dto.controllerDTO.HandleJoinRequestRequest;
import com.discuessit.communityManagemnet.dto.controllerDTO.ModeratorResponse;
import com.discuessit.communityManagemnet.dto.serviceDTO.AssignNewModeratorCommand;
import com.discuessit.communityManagemnet.dto.serviceDTO.HandleJoinRequestCommand;
import com.discuessit.communityManagemnet.dto.serviceDTO.ModeratorDto;
import com.discuessit.communityManagemnet.model.Moderator;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ModeratorMapper {

    ModeratorDto toDto(Moderator moderator);
    Moderator toEntity(ModeratorDto moderatorDto);
    AssignNewModeratorCommand toCommand(AssignNewModeratorRequest assignNewModeratorRequest);
    ModeratorResponse toResponse(Moderator moderator);
    public HandleJoinRequestCommand toHandleJoinRequestCommand(HandleJoinRequestRequest request);
}
