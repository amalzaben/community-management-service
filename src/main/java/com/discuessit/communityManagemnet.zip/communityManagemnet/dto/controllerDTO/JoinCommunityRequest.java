package com.discuessit.communityManagemnet.dto.controllerDTO;

public record JoinCommunityRequest(
        Long userId
) {
}
