package com.discuessit.communityManagemnet.dto.controllerDTO;

import com.discuessit.communityManagemnet.model.ModeratorPrivilegeType;


import java.util.List;

public record AssignNewModeratorRequest(
        Long memberToBeModeratorId,
        Long assignedByModeratorId,
        List<ModeratorPrivilegeType> privilegesList
) {
}
