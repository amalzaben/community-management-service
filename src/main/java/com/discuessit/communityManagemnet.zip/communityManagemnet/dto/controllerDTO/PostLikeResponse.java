package com.discuessit.communityManagemnet.dto.controllerDTO;

public record PostLikeResponse(
        Long likeId,
        Long userId,
        Long postId
) {
}
