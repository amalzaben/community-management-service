package com.discuessit.communityManagemnet.dto.controllerDTO;

import com.discuessit.communityManagemnet.model.MembershipStatus;

public record HandleJoinRequestRequest(
        Long memberId,
        Long moderatorId,
        MembershipStatus status
) {
}
