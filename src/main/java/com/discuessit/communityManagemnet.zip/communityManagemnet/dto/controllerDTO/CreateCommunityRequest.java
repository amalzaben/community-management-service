package com.discuessit.communityManagemnet.dto.controllerDTO;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateCommunityRequest(

        Long userId,

        String name,

        String description,

        Boolean publicCommunity
) { }
