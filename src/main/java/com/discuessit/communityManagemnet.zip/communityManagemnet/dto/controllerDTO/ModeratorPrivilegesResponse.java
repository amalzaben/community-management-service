package com.discuessit.communityManagemnet.dto.controllerDTO;

import com.discuessit.communityManagemnet.model.ModeratorPrivilegeType;

import java.util.List;

public record ModeratorPrivilegesResponse(
        Long moderatorId,
        List<ModeratorPrivilegeType>privileges
) {
}
