package com.discuessit.communityManagemnet.dto.controllerDTO;

import java.time.LocalDateTime;

public record ModeratorResponse(
        Long moderatorId
) {

}
