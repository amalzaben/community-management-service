package com.discuessit.communityManagemnet.dto.controllerDTO;

public record ArchivePostRequest(
        Long postId,
        Long memberId
) {
}
