package com.discuessit.communityManagemnet.dto.controllerDTO;

public record PendingJoinRequestResponse(
        Long memberId,
        Long userId
) {
}
