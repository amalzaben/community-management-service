package com.discuessit.communityManagemnet.dto.controllerDTO;

public record UnarchivePostRequest(
        Long postId,
        Long memberId
) {
}
