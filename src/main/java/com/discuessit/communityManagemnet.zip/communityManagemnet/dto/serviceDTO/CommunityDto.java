package com.discuessit.communityManagemnet.dto.serviceDTO;

import org.hibernate.validator.constraints.UniqueElements;

import java.time.LocalDateTime;

public record CommunityDto(
        Long communityId,
        String name,
        String description,
        Boolean publicCommunity ,
        Long membersCount,
        LocalDateTime createdAt
) {
}
