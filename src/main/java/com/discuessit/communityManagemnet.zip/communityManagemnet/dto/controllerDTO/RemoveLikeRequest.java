package com.discuessit.communityManagemnet.dto.controllerDTO;

public record RemoveLikeRequest(
        Long userId
) {
}
