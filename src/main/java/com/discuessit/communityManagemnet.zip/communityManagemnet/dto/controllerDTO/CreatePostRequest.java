package com.discuessit.communityManagemnet.dto.controllerDTO;

public record CreatePostRequest(
        Long memberId,
        Long communityId,
        String title,
        String content
) {
}
