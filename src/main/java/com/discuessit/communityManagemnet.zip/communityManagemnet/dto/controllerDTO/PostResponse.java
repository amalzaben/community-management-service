package com.discuessit.communityManagemnet.dto.controllerDTO;

public record PostResponse(
        Long postId,
        Long memberId,
        String title,
        String content,
        long likesCount,
        long commentsCount
) {
}
