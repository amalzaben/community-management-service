package com.discuessit.communityManagemnet.dto.serviceDTO;


import jakarta.validation.constraints.NotNull;

public record PendingJoinRequestDto(

        @NotNull(message = "Member ID must not be null")
        Long memberId,

        @NotNull(message = "User ID must not be null")
        Long userId
) {
}
