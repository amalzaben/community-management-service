package com.discuessit.communityManagemnet.dto.controllerDTO;

public record LikePostRequest(
        Long userId
) {
}
