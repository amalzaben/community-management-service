package com.discuessit.communityManagemnet.dto.controllerDTO;

public record CommentRequest(
        long userId,
        long postId,
        String content,
        Long parentCommentId
) {
}
