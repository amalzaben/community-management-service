package com.discuessit.communityManagemnet.dto.serviceDTO;

import com.discuessit.communityManagemnet.model.Community;

public record ModeratorDto(
        Long moderatorId
) {
}
