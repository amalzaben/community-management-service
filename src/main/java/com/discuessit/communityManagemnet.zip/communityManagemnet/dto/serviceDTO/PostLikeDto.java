package com.discuessit.communityManagemnet.dto.serviceDTO;

import jakarta.validation.constraints.NotNull;

public record PostLikeDto(
        Long likeId,
        Long userId,
        Long postId
) {
}
